@echo off
setlocal
set "EXE=%~dp0..\Liberty City Mod Loader IV.exe"
if not exist "%EXE%" (
  echo Liberty City Mod Loader IV.exe was not found.
  echo Extract the complete package and keep the app folder next to the EXE.
  pause
  exit /b 1
)
start "" "%EXE%" "%~1"
