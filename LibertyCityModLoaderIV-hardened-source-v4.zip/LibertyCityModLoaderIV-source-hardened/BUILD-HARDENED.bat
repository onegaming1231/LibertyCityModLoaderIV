@echo off
setlocal
set "APP=%~dp0app"
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
set "REF=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319"
if not exist "%CSC%" (
  set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
  set "REF=%WINDIR%\Microsoft.NET\Framework\v4.0.30319"
)

rem WPF assemblies are not stored beside csc.exe on many Windows installs.
rem Prefer the .NET Framework reference-assembly directory, then the GAC.
set "WPFREF=%ProgramFiles%\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.0"
if not exist "%WPFREF%\WindowsBase.dll" set "WPFREF=%ProgramFiles%\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8"
if not exist "%WPFREF%\WindowsBase.dll" set "WPFREF=%ProgramFiles(x86)%\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.0"
if not exist "%WPFREF%\WindowsBase.dll" set "WPFREF=%ProgramFiles(x86)%\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8"

if not exist "%WPFREF%\WindowsBase.dll" (
  set "WPFREF=%WINDIR%\Microsoft.NET\assembly\GAC_MSIL\WindowsBase\v4.0_4.0.0.0__31bf3856ad364e35"
)
if not exist "%WPFREF%\PresentationCore.dll" (
  set "WPFREF=%WINDIR%\Microsoft.NET\assembly\GAC_MSIL\PresentationCore\v4.0_4.0.0.0__31bf3856ad364e35"
)
if not exist "%CSC%" (
  echo .NET Framework C# compiler was not found.
  echo Build this on a Windows PC with .NET Framework 4 installed.
  pause
  exit /b 1
)
cd /d "%APP%"
if not exist "%WPFREF%\WindowsBase.dll" (
  echo WindowsBase.dll was not found in the .NET Framework reference assemblies or GAC.
  echo This PC needs the .NET Framework Developer/Targeting Pack with WPF support.
  goto :fail
)
if not exist "%WPFREF%\PresentationCore.dll" (
  echo PresentationCore.dll was not found in the .NET Framework reference assemblies or GAC.
  echo This PC needs the .NET Framework Developer/Targeting Pack with WPF support.
  goto :fail
)

echo Using WPF references from: %WPFREF%
echo Building LibertyUI.dll...
"%CSC%" /nologo /target:library /out:LibertyUI.dll /r:"%REF%\System.dll" /r:"%REF%\System.Core.dll" /r:"%REF%\System.Windows.Forms.dll" /r:"%REF%\System.Drawing.dll" /r:"%WPFREF%\WindowsBase.dll" /r:"%WPFREF%\PresentationCore.dll" LibertyUI.cs
if errorlevel 1 goto :fail

echo Building Liberty City Mod Loader IV.exe...
set "SMA=%WINDIR%\Microsoft.NET\assembly\GAC_MSIL\System.Management.Automation\v4.0_3.0.0.0__31bf3856ad364e35\System.Management.Automation.dll"
if not exist "%SMA%" set "SMA=%ProgramFiles%\Reference Assemblies\Microsoft\WindowsPowerShell\v1.0\System.Management.Automation.dll"
if not exist "%SMA%" (
  echo System.Management.Automation.dll was not found.
  echo Install the Windows PowerShell 5.1 reference assembly/developer components.
  goto :fail
)
"%CSC%" /nologo /target:winexe /out:"..\Liberty City Mod Loader IV.exe" /win32icon:icon.ico /r:"%REF%\System.dll" /r:"%REF%\System.Core.dll" /r:"%REF%\System.Windows.Forms.dll" /r:"%REF%\System.Drawing.dll" /r:"%SMA%" Launcher.cs
if errorlevel 1 goto :fail

echo.
echo Hardened build completed successfully.
echo Test the EXE before distributing it.
exit /b 0

:fail
echo.
echo Build failed.
pause
exit /b 1
