# Liberty City Mod Loader IV — security hardening

This variant preserves the mod loader's functional PowerShell code while removing several unnecessary malware-like distribution behaviors.

Changes:
- The BAT launcher starts the compiled EXE instead of launching PowerShell with `-ExecutionPolicy Bypass -WindowStyle Hidden`.
- The right-click fallback no longer uses `-ExecutionPolicy Bypass` or `-WindowStyle Hidden`.
- The public PowerShell build loads the bundled `LibertyUI.dll` with normal `Assembly.LoadFrom()`.
- Runtime compilation of `LibertyUI.cs` and raw-byte assembly loading are disabled in the public release path.
- The original mod-management, Nexus, download, registry context-menu, RPF, and UI functionality is otherwise left unchanged.

This is source-level hardening. The C# launcher EXE must be rebuilt on Windows before distributing the hardened release. Do not overwrite the original release until the rebuilt EXE has been tested.
