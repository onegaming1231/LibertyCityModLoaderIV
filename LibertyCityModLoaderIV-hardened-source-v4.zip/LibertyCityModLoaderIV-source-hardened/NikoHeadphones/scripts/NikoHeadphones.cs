// Niko's Headphones - YouTube Music inside GTA IV (ScriptHookDotNet plain script)
// A small modern player with a little 90s touch. Needs the YouTube Music desktop app (th-ch / pear-desktop)
// with Plugins > API Server turned on. Press F9 to open it. Settings: scripts\NikoHeadphones.ini
// Free and open source (GPL v3) - part of the Liberty City Mod Loader IV project.
using System;
using System.IO;
using System.Text;
using System.Drawing;
using System.Threading;
using System.Collections.Generic;
using System.Windows.Forms;
using GTA;

public class NikoHeadphones : Script
{
    // ================= settings =================
    Keys openKey = Keys.F9;
    int port = 26538;
    string clientId = "LibertyCityModInstaller";   // already allowed if you connected the loader's Music button
    string token = "";
    bool showToast = true;
    string iniPath, listsPath;

    // ================= look: modern dark, walkman-orange accent =================
    static readonly Color cCard = Color.FromArgb(238, 16, 16, 18);
    static readonly Color cRow = Color.FromArgb(255, 30, 30, 34);
    static readonly Color cRowSel = Color.FromArgb(255, 44, 44, 50);
    static readonly Color cLine = Color.FromArgb(255, 52, 52, 58);
    static readonly Color cTrack = Color.FromArgb(255, 70, 70, 76);
    static readonly Color cAccent = Color.FromArgb(255, 255, 122, 26);
    static readonly Color cLed = Color.FromArgb(255, 120, 230, 120);
    static readonly Color cWhite = Color.FromArgb(255, 255, 255, 255);
    static readonly Color cDim = Color.FromArgb(255, 160, 160, 168);
    static readonly Color cFaint = Color.FromArgb(255, 110, 110, 118);
    GTA.Font fTitle, fRow, fSmall, fTiny;

    // small window on the right, under the money and wanted stars
    const float PX = 0.770F, PY = 0.215F, PW = 0.210F;
    const float RH = 0.040F;       // list row height
    const int ROWS = 6;

    // ================= state =================
    bool open;
    int tab;                       // 0 Play, 1 Find, 2 Lists, 3 Queue
    static readonly string[] TABS = { "Play", "Find", "Lists", "Queue" };
    string query = "";
    bool typing = true;            // Find page: typing in the box, or picking a result
    int selSearch, selQueue, selList, selSong;
    int openList = -1;             // Lists page: -1 shows all lists, else the songs of that list
    bool naming; string newName = "";
    int deleteArm = -1; DateTime deleteUntil;
    int target;                    // the list that the + button adds to
    string toastText = ""; DateTime toastUntil = DateTime.MinValue;
    string lastVideo = "";
    string flash = ""; DateTime flashUntil = DateTime.MinValue;
    DateTime plusFlash = DateTime.MinValue;

    // shared with the network thread
    readonly object sync = new object();
    Song song; DateTime songAt;
    int connState;                 // 0 trying, 1 ok, 2 app not open, 3 needs Allow
    int volume = -1; string likeState = "";
    List<Item> results = new List<Item>(); bool searching; string searchNote = "";
    List<Item> queue = new List<Item>(); int queueNow = -1;
    readonly Queue<string[]> jobs = new Queue<string[]>();
    Thread worker; volatile bool running = true;

    // Niko's own playlists (saved in scripts\NikoHeadphones.lists)
    class PList { public string Name = ""; public List<Item> Songs = new List<Item>(); }
    List<PList> lists = new List<PList>();

    class Song { public string Title = "", Artist = "", Album = "", VideoId = "", Image = ""; public double Duration, Elapsed; public bool Paused; }
    class Item { public string Title = "", Sub = "", VideoId = "", Thumb = ""; public bool Now; }
    // pictures: downloaded on the network thread, made into textures when drawn
    readonly Dictionary<string, byte[]> picBytes = new Dictionary<string, byte[]>();
    readonly Dictionary<string, Texture> pics = new Dictionary<string, Texture>();
    readonly List<string> picWant = new List<string>();
    readonly Dictionary<string, bool> picTried = new Dictionary<string, bool>();
    // song clock: moves on its own between updates, so the time never looks stuck
    double clockBase, lastApiElapsed = -1; DateTime clockAt = DateTime.Now; string clockVid = ""; bool clockPaused;
    // live search while typing
    DateTime searchAt = DateTime.MaxValue; string lastSearched = ""; string searchFor = "";

    public NikoHeadphones()
    {
        fTitle = new GTA.Font(0.024F, FontScaling.ScreenUnits); fTitle.Color = cWhite;
        fRow = new GTA.Font(0.019F, FontScaling.ScreenUnits); fRow.Color = cWhite;
        fSmall = new GTA.Font(0.017F, FontScaling.ScreenUnits); fSmall.Color = cDim;
        fTiny = new GTA.Font(0.0145F, FontScaling.ScreenUnits); fTiny.Color = cDim;
        iniPath = Game.InstallFolder + "\\scripts\\NikoHeadphones.ini";
        listsPath = Game.InstallFolder + "\\scripts\\NikoHeadphones.lists";
        LoadIni(); LoadLists();
        try { System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072; } catch { }
        Interval = 10;
        this.Tick += new EventHandler(OnTick);
        this.KeyDown += new GTA.KeyEventHandler(OnKeyDown);
        this.PerFrameDrawing += new GraphicsEventHandler(OnDraw);
        worker = new Thread(Work); worker.IsBackground = true; worker.Start();
    }

    // ================= ini =================
    void LoadIni()
    {
        try
        {
            if (!File.Exists(iniPath)) { SaveIni(); return; }
            foreach (string raw in File.ReadAllLines(iniPath))
            {
                string l = raw.Trim(); int eq = l.IndexOf('=');
                if (eq < 1 || l.StartsWith(";")) continue;
                string k = l.Substring(0, eq).Trim().ToLower(), v = l.Substring(eq + 1).Trim();
                if (k == "key") { try { openKey = (Keys)Enum.Parse(typeof(Keys), v, true); } catch { } }
                else if (k == "port") { int p; if (int.TryParse(v, out p)) port = p; }
                else if (k == "clientid" && v.Length > 0) clientId = v;
                else if (k == "token") token = v;
                else if (k == "songpopup") showToast = v.ToLower() != "false" && v != "0";
            }
        }
        catch { }
    }
    void SaveIni()
    {
        try
        {
            File.WriteAllText(iniPath,
                "; Niko's Headphones - YouTube Music in GTA IV\r\n" +
                "; Key that opens the player\r\nKey=" + openKey + "\r\n" +
                "; YouTube Music app > Plugins > API Server port\r\nPort=" + port + "\r\n" +
                "; Show a small popup when the song changes (true/false)\r\nSongPopup=" + (showToast ? "true" : "false") + "\r\n" +
                "; Filled in by the mod - leave these\r\nClientId=" + clientId + "\r\nToken=" + token + "\r\n");
        }
        catch { }
    }

    // ================= playlists file =================
    void LoadLists()
    {
        lists.Clear();
        try
        {
            if (File.Exists(listsPath))
            {
                PList cur = null;
                foreach (string raw in File.ReadAllLines(listsPath, Encoding.UTF8))
                {
                    string l = raw.Trim(); if (l.Length == 0 || l.StartsWith(";")) continue;
                    if (l.StartsWith("[") && l.EndsWith("]")) { cur = new PList(); cur.Name = l.Substring(1, l.Length - 2); lists.Add(cur); continue; }
                    string[] p = l.Split('|');
                    if (cur != null && p.Length >= 2) { Item it = new Item(); it.VideoId = p[0]; it.Title = p[1]; it.Sub = p.Length > 2 ? p[2] : ""; it.Thumb = p.Length > 3 ? p[3] : ""; cur.Songs.Add(it); }
                }
            }
        }
        catch { }
        if (lists.Count == 0) { PList p = new PList(); p.Name = "Niko's Mix"; lists.Add(p); }
    }
    void SaveLists()
    {
        try
        {
            StringBuilder sb = new StringBuilder("; Niko's Headphones playlists - [List name] then videoId|title|artist\r\n");
            foreach (PList p in lists)
            {
                sb.Append("[" + p.Name.Replace("]", ")") + "]\r\n");
                foreach (Item it in p.Songs) sb.Append(it.VideoId + "|" + it.Title.Replace("|", "/") + "|" + it.Sub.Replace("|", "/") + "|" + it.Thumb + "\r\n");
            }
            File.WriteAllText(listsPath, sb.ToString(), Encoding.UTF8);
        }
        catch { }
    }
    void AddToTarget(string vid, string title, string sub) { AddToTarget(vid, title, sub, ""); }
    void AddToTarget(string vid, string title, string sub, string thumb)
    {
        if (String.IsNullOrEmpty(vid)) { SetFlash("Nothing to add"); return; }
        if (target < 0 || target >= lists.Count) target = 0;
        PList p = lists[target];
        foreach (Item x in p.Songs) if (x.VideoId == vid) { SetFlash("Already in " + p.Name); return; }
        Item it = new Item(); it.VideoId = vid; it.Title = title; it.Sub = sub; it.Thumb = thumb ?? ""; p.Songs.Add(it);
        SaveLists(); SetFlash("Added to " + p.Name); plusFlash = DateTime.Now.AddMilliseconds(300);
    }
    void PlayList(PList p, int start)
    {
        if (p.Songs.Count == 0) { SetFlash("This list is empty"); return; }
        List<string> j = new List<string>(); j.Add("list");
        for (int i = 0; i < p.Songs.Count; i++) j.Add(p.Songs[(start + i) % p.Songs.Count].VideoId);
        Job(j.ToArray()); SetFlash("Loading " + p.Name + "...");
    }

    // ================= network thread =================
    void Job(params string[] j) { lock (sync) jobs.Enqueue(j); }

    void Work()
    {
        DateTime nextPoll = DateTime.MinValue, nextSlow = DateTime.MinValue;
        while (running)
        {
            try
            {
                string[] j = null;
                lock (sync) if (jobs.Count > 0) j = jobs.Dequeue();
                if (j != null) { RunJob(j); continue; }
                if (DateTime.Now >= nextPoll)
                {
                    nextPoll = DateTime.Now.AddMilliseconds(open ? 1000 : 2500);
                    PollSong();
                }
                string pu = null; lock (sync) if (picWant.Count > 0) { pu = picWant[0]; picWant.RemoveAt(0); picTried[pu] = true; }
                if (pu != null) { byte[] pb = Download(pu); if (pb != null) lock (sync) picBytes[pu] = pb; continue; }
                if (open && connState == 1 && DateTime.Now >= nextSlow)
                {
                    nextSlow = DateTime.Now.AddSeconds(4);
                    PollExtras();
                }
            }
            catch { }
            Thread.Sleep(60);
        }
    }

    void RunJob(string[] j)
    {
        string kind = j[0];
        if (kind == "call") { int c; Http(j[1], j[2], j.Length > 3 ? j[3] : null, 4000, out c); nextSoon(); }
        else if (kind == "search") DoSearch(j[1], j.Length > 2);
        else if (kind == "play")
        {
            int c;
            Http("POST", "/api/v1/queue", "{\"videoId\":\"" + Esc(j[1]) + "\",\"insertPosition\":\"INSERT_AFTER_CURRENT_VIDEO\"}", 5000, out c);
            if (c < 200 || c >= 300) { SetFlash("Couldn't play that one"); return; }
            // find where it landed (right after the song that's playing) and jump there
            int at = -1;
            for (int tries = 0; tries < 10 && at < 0; tries++)
            {
                Thread.Sleep(250);
                PollQueue();
                List<Item> q; int now; lock (sync) { q = queue; now = queueNow; }
                for (int i = Math.Max(0, now + 1); i < q.Count && at < 0; i++) if (q[i].VideoId == j[1]) at = i;
                if (at < 0) for (int i = 0; i < q.Count && at < 0; i++) if (q[i].VideoId == j[1]) at = i;
            }
            if (at >= 0) { Http("PATCH", "/api/v1/queue", "{\"index\":" + at + "}", 5000, out c); Http("POST", "/api/v1/play", null, 4000, out c); }
            else Http("POST", "/api/v1/next", null, 4000, out c);
            SetFlash("Playing now");
            nextSoon();
        }
        else if (kind == "queue") { PollQueue(); }
        else if (kind == "addq")
        {
            int c; Http("POST", "/api/v1/queue", "{\"videoId\":\"" + Esc(j[1]) + "\",\"insertPosition\":\"INSERT_AT_END\"}", 5000, out c);
            SetFlash(c >= 200 && c < 300 ? "Added to Up Next" : "Couldn't add it");
        }
        else if (kind == "list")
        {
            // play one of Niko's playlists: empty the queue, add every song, start at the first
            int c; Http("DELETE", "/api/v1/queue", null, 5000, out c);
            int added = 0;
            for (int i = 1; i < j.Length; i++)
            {
                Http("POST", "/api/v1/queue", "{\"videoId\":\"" + Esc(j[i]) + "\",\"insertPosition\":\"INSERT_AT_END\"}", 5000, out c);
                if (c >= 200 && c < 300) added++;
            }
            if (added > 0)
            {
                Thread.Sleep(400);
                Http("PATCH", "/api/v1/queue", "{\"index\":0}", 5000, out c);
                Http("POST", "/api/v1/play", null, 4000, out c);
                SetFlash("Playing " + added + " songs");
            }
            else SetFlash("Couldn't load the playlist");
            nextSoon();
        }
    }
    void nextSoon() { Thread.Sleep(250); PollSong(); }

    void PollSong()
    {
        int c; string s = Http("GET", "/api/v1/song", null, 2500, out c);
        if (c == -1) { lock (sync) { connState = 2; } return; }
        if (c == 401 || c == 403) { Authorize(); return; }
        lock (sync) connState = 1;
        if (c == 204 || s == null) { lock (sync) song = null; return; }
        object o = Json.Parse(s); Dictionary<string, object> d = o as Dictionary<string, object>;
        if (d == null) return;
        Song n = new Song();
        n.Title = Json.Str(d, "title"); n.Artist = Json.Str(d, "artist"); n.Album = Json.Str(d, "album");
        n.VideoId = Json.Str(d, "videoId"); n.Image = Json.Str(d, "imageSrc");
        n.Duration = Json.Num(d, "songDuration"); n.Elapsed = Json.Num(d, "elapsedSeconds");
        n.Paused = Json.Bool(d, "isPaused");
        lock (sync)
        {
            // keep our own clock; only follow the app when the song, play/pause, or position really changed
            double est = clockPaused ? clockBase : clockBase + (DateTime.Now - clockAt).TotalSeconds;
            bool apiMoved = Math.Abs(n.Elapsed - lastApiElapsed) > 0.01;
            if (n.VideoId != clockVid || n.Paused != clockPaused || (apiMoved && Math.Abs(n.Elapsed - est) > 2.5))
            { clockBase = n.Paused ? n.Elapsed : n.Elapsed; clockAt = DateTime.Now; }
            if (n.Paused && !clockPaused) { clockBase = est; }
            clockVid = n.VideoId; clockPaused = n.Paused; lastApiElapsed = n.Elapsed;
            song = n; songAt = DateTime.Now;
            if (n.Image.Length > 0) WantPic(n.Image);
        }
    }

    void PollExtras()
    {
        int c; string s = Http("GET", "/api/v1/volume", null, 2500, out c);
        Dictionary<string, object> d = Json.Parse(s) as Dictionary<string, object>;
        if (d != null) lock (sync) volume = (int)Math.Round(Json.Num(d, "state"));
        s = Http("GET", "/api/v1/like-state", null, 2500, out c);
        d = Json.Parse(s) as Dictionary<string, object>;
        if (d != null) lock (sync) likeState = Json.Str(d, "state");
        if (tab == 2) PollQueue();
    }

    void Authorize()
    {
        lock (sync) connState = 3;
        int c; string s = Http("POST", "/auth/" + Uri.EscapeDataString(clientId), null, 60000, out c, false);
        Dictionary<string, object> d = Json.Parse(s) as Dictionary<string, object>;
        string t = d == null ? "" : Json.Str(d, "accessToken");
        if (t.Length > 0) { token = t; SaveIni(); lock (sync) connState = 1; }
        else Thread.Sleep(3000);
    }

    void DoSearch(string q, bool pick)
    {
        lock (sync) { if (q != searchFor) return; searching = true; searchNote = ""; }
        int c; string s = Http("POST", "/api/v1/search", "{\"query\":\"" + Esc(q) + "\"}", 10000, out c);
        List<Item> found = new List<Item>();
        if (s != null) Walk(Json.Parse(s), found, new Dictionary<string, bool>(), "search");
        lock (sync)
        {
            if (q != searchFor) return;          // you kept typing - a newer search is on its way
            results = found; searching = false; selSearch = 0;
            if (pick && found.Count > 0) typing = false;
            searchNote = found.Count == 0 ? (c == -1 ? "YouTube Music isn't open" : "No songs found") : "";
            for (int i = 0; i < found.Count && i < 12; i++) if (found[i].Thumb.Length > 0) WantPic(found[i].Thumb);
        }
    }

    void PollQueue()
    {
        int c; string s = Http("GET", "/api/v1/queue", null, 5000, out c);
        if (s == null) return;
        List<Item> found = new List<Item>();
        Walk(Json.Parse(s), found, new Dictionary<string, bool>(), "queue");
        int now = -1; for (int i = 0; i < found.Count; i++) if (found[i].Now) now = i;
        lock (sync) { queue = found; queueNow = now; }
    }

    // search results and queue items are deep inside YouTube Music's own data - find them wherever they are
    void Walk(object o, List<Item> into, Dictionary<string, bool> seen, string mode)
    {
        if (into.Count >= 40 || o == null) return;
        List<object> list = o as List<object>;
        if (list != null) { foreach (object x in list) Walk(x, into, seen, mode); return; }
        Dictionary<string, object> d = o as Dictionary<string, object>;
        if (d == null) return;
        object r;
        if (mode == "search" && d.TryGetValue("musicResponsiveListItemRenderer", out r))
        {
            Dictionary<string, object> it = r as Dictionary<string, object>;
            List<object> cols = it == null ? null : Json.Get(it, "flexColumns") as List<object>;
            string vid = FindKey(Json.Get(it, "playlistItemData"), "videoId");
            if (vid == "") vid = FindWatchId(it);
            if (cols != null && cols.Count > 0 && vid != "" && !seen.ContainsKey(vid))
            {
                Item n = new Item(); n.VideoId = vid;
                n.Title = Runs(Json.Path(cols[0], "musicResponsiveListItemFlexColumnRenderer", "text"));
                if (cols.Count > 1) n.Sub = Runs(Json.Path(cols[1], "musicResponsiveListItemFlexColumnRenderer", "text"));
                n.Thumb = FindThumb(Json.Get(it, "thumbnail"));
                if (n.Title.Length > 0) { seen[vid] = true; into.Add(n); }
            }
            return;
        }
        if (mode == "search" && d.TryGetValue("musicCardShelfRenderer", out r))
        {
            Dictionary<string, object> it = r as Dictionary<string, object>;
            string vid = FindWatchId(Json.Get(it, "title"));
            if (vid != "" && !seen.ContainsKey(vid))
            {
                Item n = new Item(); n.VideoId = vid; n.Title = Runs(Json.Get(it, "title")); n.Sub = Runs(Json.Get(it, "subtitle")); n.Thumb = FindThumb(Json.Get(it, "thumbnail"));
                if (n.Title.Length > 0) { seen[vid] = true; into.Add(n); }
            }
            Walk(Json.Get(it, "contents"), into, seen, mode);
            return;
        }
        if (mode == "queue" && d.TryGetValue("playlistPanelVideoRenderer", out r))
        {
            Dictionary<string, object> it = r as Dictionary<string, object>;
            if (it != null)
            {
                Item n = new Item(); n.VideoId = Json.Str(it, "videoId");
                n.Title = Runs(Json.Get(it, "title")); n.Sub = Runs(Json.Get(it, "shortBylineText"));
                n.Now = Json.Bool(it, "selected");
                n.Thumb = FindThumb(Json.Get(it, "thumbnail"));
                if (n.Title.Length > 0) into.Add(n);
            }
            return;
        }
        foreach (KeyValuePair<string, object> kv in d) Walk(kv.Value, into, seen, mode);
    }
    // the smallest picture YouTube Music gives for an item
    static string FindThumb(object o)
    {
        Dictionary<string, object> d = o as Dictionary<string, object>;
        if (d != null)
        {
            List<object> th = Json.Get(d, "thumbnails") as List<object>;
            if (th != null && th.Count > 0) return Json.Str(th[0] as Dictionary<string, object>, "url");
            foreach (KeyValuePair<string, object> kv in d) { string u = FindThumb(kv.Value); if (u != "") return u; }
        }
        List<object> l = o as List<object>;
        if (l != null) foreach (object x in l) { string u = FindThumb(x); if (u != "") return u; }
        return "";
    }
    void WantPic(string url) { if (!picTried.ContainsKey(url) && !picWant.Contains(url)) picWant.Add(url); }
    static string Runs(object text)
    {
        List<object> runs = Json.Get(text as Dictionary<string, object>, "runs") as List<object>;
        if (runs == null) return Json.Str(text as Dictionary<string, object>, "simpleText");
        StringBuilder sb = new StringBuilder();
        foreach (object r in runs) sb.Append(Json.Str(r as Dictionary<string, object>, "text"));
        return sb.ToString().Replace("\u2022", "-").Trim();
    }
    static string FindWatchId(object o)
    {
        Dictionary<string, object> d = o as Dictionary<string, object>;
        if (d != null)
        {
            object w; if (d.TryGetValue("watchEndpoint", out w)) { string v = Json.Str(w as Dictionary<string, object>, "videoId"); if (v != "") return v; }
            foreach (KeyValuePair<string, object> kv in d) { string v = FindWatchId(kv.Value); if (v != "") return v; }
        }
        List<object> l = o as List<object>;
        if (l != null) foreach (object x in l) { string v = FindWatchId(x); if (v != "") return v; }
        return "";
    }
    static string FindKey(object o, string key)
    {
        Dictionary<string, object> d = o as Dictionary<string, object>;
        return d == null ? "" : Json.Str(d, key);
    }


    byte[] Download(string url)
    {
        string u = url;
        if (u.StartsWith("//")) u = "https:" + u;
        // ask Google for a small square jpg
        u = System.Text.RegularExpressions.Regex.Replace(u, "=w\\d+-h\\d+[^/]*$", "=w120-h120-l90-rj");
        try
        {
            System.Net.HttpWebRequest r = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(u);
            r.Timeout = 6000; r.UserAgent = "Mozilla/5.0"; r.Accept = "image/jpeg,image/png";
            using (System.Net.WebResponse resp = r.GetResponse())
            using (Stream st = resp.GetResponseStream())
            using (System.IO.MemoryStream ms = new System.IO.MemoryStream()) { byte[] buf = new byte[16384]; int n; while ((n = st.Read(buf, 0, buf.Length)) > 0) ms.Write(buf, 0, n); return ms.ToArray(); }
        }
        catch { return null; }
    }
    string Http(string method, string path, string body, int timeout, out int code) { return Http(method, path, body, timeout, out code, true); }
    string Http(string method, string path, string body, int timeout, out int code, bool auth)
    {
        code = -1;
        try
        {
            System.Net.HttpWebRequest r = (System.Net.HttpWebRequest)System.Net.WebRequest.Create("http://127.0.0.1:" + port + path);
            r.Method = method; r.Timeout = timeout; r.ReadWriteTimeout = timeout; r.Proxy = null;
            if (auth && token.Length > 0) r.Headers["Authorization"] = "Bearer " + token;
            if (body != null)
            {
                byte[] b = Encoding.UTF8.GetBytes(body);
                r.ContentType = "application/json"; r.ContentLength = b.Length;
                using (Stream st = r.GetRequestStream()) st.Write(b, 0, b.Length);
            }
            else if (method != "GET") r.ContentLength = 0;
            using (System.Net.HttpWebResponse resp = (System.Net.HttpWebResponse)r.GetResponse())
            {
                code = (int)resp.StatusCode;
                using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) return sr.ReadToEnd();
            }
        }
        catch (System.Net.WebException e)
        {
            System.Net.HttpWebResponse hr = e.Response as System.Net.HttpWebResponse;
            if (hr != null) code = (int)hr.StatusCode;
            return null;
        }
        catch { return null; }
    }
    static string Esc(string s)
    {
        StringBuilder sb = new StringBuilder();
        foreach (char ch in s ?? "")
        {
            if (ch == '"' || ch == '\\') { sb.Append('\\'); sb.Append(ch); }
            else if (ch < ' ') sb.Append(' ');
            else sb.Append(ch);
        }
        return sb.ToString();
    }
    void SetFlash(string t) { flash = t; flashUntil = DateTime.Now.AddSeconds(2); }


    // ================= game thread =================
    void OnTick(object sender, EventArgs e)
    {
        if (screenFix <= 0) ReadScreen();
        Song s; lock (sync) s = song;
        if (s != null && s.VideoId != "" && s.VideoId != lastVideo)
        {
            if (lastVideo != "" && showToast && !open) { toastText = s.Title + " - " + s.Artist; toastUntil = DateTime.Now.AddSeconds(5); }
            lastVideo = s.VideoId;
        }
        if (deleteArm >= 0 && DateTime.Now > deleteUntil) deleteArm = -1;
        // live search: shortly after you stop typing
        if (DateTime.Now >= searchAt)
        {
            searchAt = DateTime.MaxValue;
            string q = query.Trim();
            if (q.Length >= 2 && q != lastSearched) { lastSearched = q; lock (sync) { searchFor = q; searching = true; } Job("search", q); }
        }
    }

    void SetOpen(bool on)
    {
        open = on; naming = false;
        try { GTA.Native.Function.Call("SET_PLAYER_CONTROL", Player, !on); } catch { }
        if (on) { Job("call", "GET", "/api/v1/song"); if (tab == 3) Job("queue"); }
    }

    void OnKeyDown(object sender, GTA.KeyEventArgs e)
    {
        Keys k = e.Key;
        if (k == openKey) { SetOpen(!open); return; }
        if (!open) return;
        bool shift = isKeyPressed(Keys.ShiftKey);

        // typing a name for a new playlist
        if (naming)
        {
            if (k == Keys.Enter)
            {
                string n = newName.Trim();
                if (n.Length > 0) { PList p = new PList(); p.Name = n; lists.Add(p); target = lists.Count - 1; selList = target; SaveLists(); SetFlash("Made " + n); }
                naming = false;
            }
            else if (k == Keys.Back) { if (newName.Length > 0) newName = newName.Substring(0, newName.Length - 1); else naming = false; }
            else { string ch = KeyChar(k, shift); if (ch != null && newName.Length < 24) newName += ch; }
            return;
        }

        if (k == Keys.Tab) { tab = (tab + (shift ? 3 : 1)) % 4; typing = tab == 1 && results.Count == 0; openList = -1; if (tab == 3) Job("queue"); return; }

        if (tab == 1 && typing)
        {
            if (k == Keys.Enter)
            {
                string q = query.Trim();
                if (q.Length == 0) return;
                if (q == lastSearched && results.Count > 0) { typing = false; return; }   // results are already here
                lastSearched = q; searchAt = DateTime.MaxValue;
                lock (sync) { searchFor = q; searching = true; }
                Job("search", q, "pick");
                return;
            }
            if (k == Keys.Back) { if (query.Length > 0) { query = query.Substring(0, query.Length - 1); searchAt = DateTime.Now.AddMilliseconds(600); } return; }
            if (k == Keys.Down) { if (results.Count > 0) typing = false; return; }
            string ch = KeyChar(k, shift);
            if (ch != null && query.Length < 60) { query += ch; searchAt = DateTime.Now.AddMilliseconds(600); }
            return;
        }

        if (tab == 0)
        {
            Song s; lock (sync) s = song;
            if (k == Keys.Enter || k == Keys.Space) Job("call", "POST", "/api/v1/toggle-play");
            else if (k == Keys.Right) Job("call", "POST", "/api/v1/next");
            else if (k == Keys.Left) Job("call", "POST", "/api/v1/previous");
            else if (k == Keys.Up || k == Keys.Down)
            {
                int v = volume < 0 ? 50 : volume; v = Math.Max(0, Math.Min(100, v + (k == Keys.Up ? 5 : -5)));
                lock (sync) volume = v; Job("call", "POST", "/api/v1/volume", "{\"volume\":" + v + "}");
            }
            else if (k == Keys.L) { Job("call", "POST", "/api/v1/like"); lock (sync) likeState = likeState == "LIKE" ? "INDIFFERENT" : "LIKE"; }
            else if (k == Keys.A && s != null) AddToTarget(s.VideoId, s.Title, s.Artist, s.Image);
            else if (k == Keys.Back) SetOpen(false);
        }
        else if (tab == 1)
        {
            int n = results.Count;
            if (k == Keys.Up) { if (selSearch == 0) typing = true; else selSearch--; }
            else if (k == Keys.Down) { if (n > 0) selSearch = Math.Min(n - 1, selSearch + 1); }
            else if (k == Keys.Enter) { if (selSearch < n) Job("play", results[selSearch].VideoId); }
            else if (k == Keys.A) { if (selSearch < n) AddToTarget(results[selSearch].VideoId, results[selSearch].Title, results[selSearch].Sub, results[selSearch].Thumb); }
            else if (k == Keys.Q) { if (selSearch < n) Job("addq", results[selSearch].VideoId); }
            else if (k == Keys.Back) typing = true;
        }
        else if (tab == 2)
        {
            if (openList < 0)
            {
                int n = lists.Count + 1;   // last row is "+ New list"
                if (k == Keys.Up) selList = Math.Max(0, selList - 1);
                else if (k == Keys.Down) selList = Math.Min(n - 1, selList + 1);
                else if (k == Keys.Enter) { if (selList == lists.Count) { naming = true; newName = ""; } else PlayList(lists[selList], 0); }
                else if (k == Keys.Right) { if (selList < lists.Count) { openList = selList; selSong = 0; } }
                else if (k == Keys.T) { if (selList < lists.Count) { target = selList; SetFlash("+ now adds to " + lists[target].Name); } }
                else if (k == Keys.Delete)
                {
                    if (selList < lists.Count)
                    {
                        if (deleteArm == selList) { string nm = lists[selList].Name; lists.RemoveAt(selList); if (lists.Count == 0) { PList p = new PList(); p.Name = "Niko's Mix"; lists.Add(p); } target = 0; selList = Math.Min(selList, lists.Count); deleteArm = -1; SaveLists(); SetFlash("Deleted " + nm); }
                        else { deleteArm = selList; deleteUntil = DateTime.Now.AddSeconds(3); SetFlash("Press Delete again to remove it"); }
                    }
                }
                else if (k == Keys.Back) SetOpen(false);
            }
            else
            {
                PList p = lists[openList]; int n = p.Songs.Count;
                if (k == Keys.Up) selSong = Math.Max(0, selSong - 1);
                else if (k == Keys.Down) selSong = Math.Min(Math.Max(0, n - 1), selSong + 1);
                else if (k == Keys.Enter) PlayList(p, selSong);
                else if (k == Keys.Delete) { if (selSong < n) { p.Songs.RemoveAt(selSong); selSong = Math.Max(0, Math.Min(selSong, p.Songs.Count - 1)); SaveLists(); SetFlash("Removed"); } }
                else if (k == Keys.Left || k == Keys.Back) openList = -1;
            }
        }
        else if (tab == 3)
        {
            int n = queue.Count;
            if (k == Keys.Up) selQueue = Math.Max(0, selQueue - 1);
            else if (k == Keys.Down) { if (n > 0) selQueue = Math.Min(n - 1, selQueue + 1); }
            else if (k == Keys.Enter) { if (selQueue < n) { Job("call", "PATCH", "/api/v1/queue", "{\"index\":" + selQueue + "}"); Job("queue"); SetFlash("Jumping to that song"); } }
            else if (k == Keys.A) { if (selQueue < n) AddToTarget(queue[selQueue].VideoId, queue[selQueue].Title, queue[selQueue].Sub, queue[selQueue].Thumb); }
            else if (k == Keys.Back) SetOpen(false);
        }
    }

    static string KeyChar(Keys k, bool shift)
    {
        if (k >= Keys.A && k <= Keys.Z) { char c = (char)('a' + (k - Keys.A)); return (shift ? Char.ToUpper(c) : c).ToString(); }
        if (k >= Keys.D0 && k <= Keys.D9) return ((char)('0' + (k - Keys.D0))).ToString();
        if (k >= Keys.NumPad0 && k <= Keys.NumPad9) return ((char)('0' + (k - Keys.NumPad0))).ToString();
        if (k == Keys.Space) return " ";
        if (k == Keys.OemMinus || k == Keys.Subtract) return "-";
        if (k == Keys.Oemcomma) return ",";
        if (k == Keys.OemPeriod) return ".";
        if (k == Keys.OemQuotes) return "'";
        return null;
    }

    // ================= drawing: modern dark card with a little 90s touch =================
    void OnDraw(object sender, GraphicsEventArgs e)
    {
        try { e.Graphics.Scaling = FontScaling.ScreenUnits; DrawAll(e.Graphics); } catch (Exception ex) { LogError("draw", ex); }
    }
    void DrawAll(GTA.Graphics g)
    {
        Song s; int cs; lock (sync) { s = song; cs = connState; }
        if (!open) { if (DateTime.Now < toastUntil && s != null) DrawToast(g, s); return; }

        float listH = tab == 0 ? 0F : (tab == 1 ? 0.034F : 0F) + RH * ROWS + 0.006F;
        float nowH = tab == 0 ? 0.150F : 0.062F;
        float H = 0.034F + 0.030F + nowH + listH + 0.024F;
        // card + soft shadow + thin border
        Box(g, PX + 0.003F, PY + 0.005F, PW, H, Color.FromArgb(90, 0, 0, 0));
        Box(g, PX, PY, PW, H, cCard);
        Frame(g, PX, PY, PW, H, cLine);
        Box(g, PX, PY, PW, 0.003F, cAccent);                       // walkman-orange top stripe

        // header: tiny cassette + name
        float y = PY + 0.006F;
        Cassette(g, PX + 0.010F, y + 0.004F, 0.026F, 0.020F, s != null && !s.Paused);
        Text(g, "NIKO'S HEADPHONES", PX + 0.042F, y, PW - 0.05F, 0.028F, fTiny, TextAlignment.Left | TextAlignment.VerticalCenter, cDim);
        int v; string like; lock (sync) { v = volume; like = likeState; }
        LedVolume(g, PX + PW - 0.052F, y + 0.009F, v);
        y += 0.034F;

        // tabs as text with an accent underline
        float tw = (PW - 0.016F) / 4F;
        for (int i = 0; i < 4; i++)
        {
            float tx = PX + 0.008F + i * tw;
            Text(g, TABS[i], tx, y, tw, 0.024F, fSmall, TextAlignment.Center | TextAlignment.VerticalCenter, i == tab ? cWhite : cDim);
            if (i == tab) Box(g, tx + tw * 0.25F, y + 0.023F, tw * 0.5F, 0.0025F, cAccent);
        }
        Box(g, PX + 0.008F, y + 0.027F, PW - 0.016F, 0.001F, cLine);
        y += 0.030F;

        if (cs == 2) { Message(g, y, "YouTube Music isn't open", "Open the app and turn on Plugins > API Server"); y += nowH; }
        else if (cs == 3) { Message(g, y, "Waiting for YouTube Music", "Alt-Tab to it and click Allow (only once)"); y += nowH; }
        else if (tab == 0) { DrawNowBig(g, s, y, like); y += nowH; }
        else { DrawNowSmall(g, s, y); y += nowH; }

        if (tab == 1) y = DrawFind(g, y);
        else if (tab == 2) y = DrawLists(g, y);
        else if (tab == 3) y = DrawQueuePage(g, y);

        // hint line
        string help;
        if (naming) help = "Type a name  -  Enter to save";
        else if (tab == 0) help = "Enter pause   < > skip   ^ v volume   L like   A add to list";
        else if (tab == 1) help = typing ? "Type a song  -  Enter to search  -  v to pick" : "Enter play   A add to list   Q queue   Backspace edit";
        else if (tab == 2) help = openList < 0 ? "Enter play   > open   T set as list for A   Del remove" : "Enter play from here   Del remove   < back";
        else help = "Enter play this   A add to list";
        bool fl = DateTime.Now < flashUntil;
        Text(g, fl ? flash : help, PX + 0.010F, y, PW - 0.020F, 0.022F, fTiny, TextAlignment.Left | TextAlignment.VerticalCenter | TextAlignment.SingleLine, fl ? cAccent : cFaint);
    }

    void DrawNowBig(GTA.Graphics g, Song s, float y, string like)
    {
        if (s == null) { Message(g, y, "Nothing playing", "Press Tab and find a song"); return; }
        double el = Elapsed(s);
        // cover + title block, little music bars on the right
        float ah = 0.056F, aw = SquareW(ah);
        if (!Pic(g, s.Image, PX + 0.010F, y + 0.002F, ah)) { Box(g, PX + 0.010F, y + 0.002F, aw, ah, cRow); Cassette(g, PX + 0.010F + aw * 0.2F, y + 0.002F + ah * 0.3F, aw * 0.6F, ah * 0.4F, !s.Paused); }
        float tx = PX + 0.018F + aw, tw = PX + PW - 0.034F - tx;
        Text(g, Marquee(s.Title, 22), tx, y + 0.004F, tw, 0.028F, fTitle, TextAlignment.Left | TextAlignment.VerticalCenter | TextAlignment.SingleLine, cWhite);
        Text(g, s.Artist + (String.IsNullOrEmpty(s.Album) ? "" : "  -  " + s.Album), tx, y + 0.032F, tw, 0.022F, fSmall, TextAlignment.Left | TextAlignment.VerticalCenter | TextAlignment.SingleLine, cDim);
        Bars(g, PX + PW - 0.030F, y + 0.050F, 5, s.Paused);
        // progress
        float bx = PX + 0.012F, bw = PW - 0.024F, by = y + 0.072F, frac = s.Duration > 0 ? (float)(el / s.Duration) : 0F;
        Box(g, bx, by, bw, 0.003F, cTrack); Box(g, bx, by, bw * frac, 0.003F, cAccent);
        Box(g, bx + bw * frac - 0.002F, by - 0.0035F, 0.004F, 0.010F, cWhite);
        Text(g, Time(el), bx, by + 0.006F, 0.05F, 0.018F, fTiny, TextAlignment.Left, cDim);
        Text(g, Time(s.Duration), bx + bw - 0.05F, by + 0.006F, 0.05F, 0.018F, fTiny, TextAlignment.Right, cDim);
        // controls: prev, big play/pause, next, like
        float cy = y + 0.098F, ch = 0.040F, cw = ch / 1.7777F / ScreenFix(), mid = PX + PW / 2F;
        Text(g, "|<", mid - 0.060F, cy, 0.030F, ch, fTitle, TextAlignment.Center | TextAlignment.VerticalCenter, cWhite);
        Box(g, mid - cw / 2F, cy, cw, ch, cWhite);
        Text(g, s.Paused ? ">" : "||", mid - cw / 2F, cy, cw, ch, fTitle, TextAlignment.Center | TextAlignment.VerticalCenter, cCard);
        Text(g, ">|", mid + 0.030F, cy, 0.030F, ch, fTitle, TextAlignment.Center | TextAlignment.VerticalCenter, cWhite);
        Text(g, like == "LIKE" ? "LIKED" : "LIKE", PX + PW - 0.050F, cy, 0.042F, ch, fTiny, TextAlignment.Right | TextAlignment.VerticalCenter, like == "LIKE" ? cAccent : cFaint);
    }

    void DrawNowSmall(GTA.Graphics g, Song s, float y)
    {
        Box(g, PX + 0.008F, y + 0.004F, PW - 0.016F, 0.050F, cRow);
        if (s == null) { Text(g, "Nothing playing", PX + 0.014F, y + 0.004F, PW - 0.03F, 0.050F, fSmall, TextAlignment.Left | TextAlignment.VerticalCenter, cDim); return; }
        float ph = 0.042F;
        if (!Pic(g, s.Image, PX + 0.012F, y + 0.008F, ph)) Bars(g, PX + 0.014F, y + 0.040F, 4, s.Paused);
        float tx = PX + 0.020F + SquareW(ph);
        Text(g, Marquee(s.Title, 26), tx, y + 0.006F, PX + PW - 0.064F - tx, 0.024F, fRow, TextAlignment.Left | TextAlignment.VerticalCenter | TextAlignment.SingleLine, cWhite);
        Text(g, s.Artist, tx, y + 0.028F, PX + PW - 0.064F - tx, 0.020F, fTiny, TextAlignment.Left | TextAlignment.VerticalCenter | TextAlignment.SingleLine, cDim);
        Text(g, Time(Elapsed(s)), PX + PW - 0.060F, y + 0.004F, 0.048F, 0.050F, fSmall, TextAlignment.Right | TextAlignment.VerticalCenter, s.Paused ? cFaint : cAccent);
        float frac = s.Duration > 0 ? (float)(Elapsed(s) / s.Duration) : 0F;
        Box(g, PX + 0.008F, y + 0.052F, (PW - 0.016F) * frac, 0.002F, cAccent);
    }

    float DrawFind(GTA.Graphics g, float y)
    {
        float x = PX + 0.008F, w = PW - 0.016F;
        Box(g, x, y, w, 0.028F, typing ? cRowSel : cRow);
        Box(g, x, y + 0.026F, w, 0.002F, typing ? cAccent : cLine);
        string shown = query + (typing && DateTime.Now.Millisecond < 500 ? "|" : "");
        bool empty = query.Length == 0;
        Text(g, empty ? (typing ? "|  Search songs or artists" : "Search songs or artists") : shown, x + 0.008F, y, w - 0.016F, 0.028F, fRow, TextAlignment.Left | TextAlignment.VerticalCenter | TextAlignment.SingleLine, empty ? cFaint : cWhite);
        y += 0.034F;
        List<Item> r; bool busy; string note; lock (sync) { r = results; busy = searching; note = searchNote; }
        return List(g, y, r, typing ? -1 : selSearch, -1, busy ? "Searching..." : (note.Length > 0 ? note : "Results show here"));
    }

    float DrawLists(GTA.Graphics g, float y)
    {
        List<Item> rows = new List<Item>();
        if (openList < 0)
        {
            for (int i = 0; i < lists.Count; i++) { Item it = new Item(); it.Title = lists[i].Name; it.Sub = lists[i].Songs.Count + " songs" + (i == target ? "  -  A adds here" : ""); rows.Add(it); }
            Item add = new Item(); add.Title = naming ? newName + (DateTime.Now.Millisecond < 500 ? "|" : "") : "+  New list"; add.Sub = naming ? "Type a name, Enter to save" : ""; rows.Add(add);
            return List(g, y, rows, selList, deleteArm, "");
        }
        PList p = lists[openList];
        return List(g, y, p.Songs, selSong, -1, "Empty - press A on any song to add it here");
    }

    float DrawQueuePage(GTA.Graphics g, float y)
    {
        List<Item> q; int now; lock (sync) { q = queue; now = queueNow; }
        if (selQueue >= q.Count) selQueue = Math.Max(0, q.Count - 1);
        return List(g, y, q, selQueue, now, "Nothing up next");
    }

    float List(GTA.Graphics g, float y, List<Item> rows, int sel, int mark, string empty)
    {
        float x = PX + 0.008F, w = PW - 0.016F, h = RH * ROWS;
        if (rows.Count == 0) Text(g, empty, x + 0.004F, y + 0.006F, w - 0.008F, 0.024F, fSmall, TextAlignment.Left | TextAlignment.SingleLine, cDim);
        int first = sel < 0 ? 0 : Math.Max(0, Math.Min(sel - ROWS / 2, rows.Count - ROWS));
        for (int i = first; i < rows.Count && i < first + ROWS; i++)
        {
            float ry = y + (i - first) * RH;
            if (i == sel) { Box(g, x, ry + 0.001F, w, RH - 0.003F, cRowSel); Box(g, x, ry + 0.001F, 0.002F, RH - 0.003F, cAccent); }
            Color tc = i == mark ? cAccent : cWhite;
            bool hasSub = rows[i].Sub.Length > 0;
            float tx = x + 0.008F;
            if (rows[i].Thumb.Length > 0)
            {
                float th = RH - 0.010F;
                if (!Pic(g, rows[i].Thumb, x + 0.006F, ry + 0.004F, th)) { Box(g, x + 0.006F, ry + 0.004F, SquareW(th), th, cRow); WantPicSafe(rows[i].Thumb); }
                tx = x + 0.012F + SquareW(th);
            }
            Text(g, rows[i].Title, tx, ry + (hasSub ? 0.002F : 0F), x + w - 0.008F - tx, hasSub ? 0.020F : RH, fRow, TextAlignment.Left | TextAlignment.VerticalCenter | TextAlignment.SingleLine, tc);
            if (hasSub) Text(g, rows[i].Sub, tx, ry + 0.019F, x + w - 0.008F - tx, 0.016F, fTiny, TextAlignment.Left | TextAlignment.VerticalCenter | TextAlignment.SingleLine, cDim);
        }
        if (rows.Count > ROWS)
        {
            float bh = h * ROWS / rows.Count, by = y + (h - bh) * first / Math.Max(1, rows.Count - ROWS);
            Box(g, x + w - 0.002F, by, 0.002F, bh, cTrack);
        }
        return y + h + 0.006F;
    }

    void Message(GTA.Graphics g, float y, string a, string b)
    {
        Text(g, a, PX + 0.012F, y + 0.012F, PW - 0.024F, 0.026F, fRow, TextAlignment.Left | TextAlignment.SingleLine, cWhite);
        Text(g, b, PX + 0.012F, y + 0.038F, PW - 0.024F, 0.020F, fTiny, TextAlignment.Left | TextAlignment.SingleLine, cDim);
    }

    void DrawToast(GTA.Graphics g, Song s)
    {
        float w = PW, h = 0.048F, x = PX, y = PY;
        Box(g, x + 0.003F, y + 0.004F, w, h, Color.FromArgb(90, 0, 0, 0));
        Box(g, x, y, w, h, cCard); Box(g, x, y, 0.003F, h, cAccent);
        if (!Pic(g, s.Image, x + 0.009F, y + 0.006F, 0.036F)) Cassette(g, x + 0.010F, y + 0.013F, 0.026F, 0.020F, true);
        Text(g, s.Title, x + 0.044F, y + 0.004F, w - 0.052F, 0.022F, fRow, TextAlignment.Left | TextAlignment.VerticalCenter | TextAlignment.SingleLine, cWhite);
        Text(g, s.Artist, x + 0.044F, y + 0.025F, w - 0.052F, 0.018F, fTiny, TextAlignment.Left | TextAlignment.VerticalCenter | TextAlignment.SingleLine, cDim);
    }

    // a square picture (album cover). Returns false if it isn't ready yet.
    bool Pic(GTA.Graphics g, string url, float x, float y, float h)
    {
        if (String.IsNullOrEmpty(url)) return false;
        Texture t;
        if (!pics.TryGetValue(url, out t))
        {
            byte[] b; lock (sync) { if (!picBytes.TryGetValue(url, out b)) b = null; else picBytes.Remove(url); }
            if (b == null || pics.Count > 300) return false;
            try { t = new Texture(b); } catch { t = null; }
            pics[url] = t;
        }
        if (t == null) return false;
        float w = h / (1.7777F * ScreenFix());
        try { g.DrawSprite(t, new RectangleF(x, y, w, h)); return true; } catch { pics[url] = null; return false; }
    }
    float SquareW(float h) { return h / (1.7777F * ScreenFix()); }
    void WantPicSafe(string url) { lock (sync) WantPic(url); }

    // ---- the little 90s touches ----
    // a tiny cassette: the reels turn while music plays
    void Cassette(GTA.Graphics g, float x, float y, float w, float h, bool playing)
    {
        Box(g, x, y, w, h, cAccent);
        Box(g, x + w * 0.12F, y + h * 0.18F, w * 0.76F, h * 0.42F, cCard);
        float r = w * 0.16F, rh = r * 1.7777F * ScreenFix();
        double t = (DateTime.Now - DateTime.Today).TotalSeconds;
        for (int i = 0; i < 2; i++)
        {
            float cx = x + w * (i == 0 ? 0.32F : 0.68F) - r / 2F, cy = y + h * 0.39F - rh / 2F;
            Box(g, cx, cy, r, rh, cWhite);
            bool tick = playing && ((int)(t * 6) + i) % 2 == 0;
            Box(g, cx + r * (tick ? 0.2F : 0.4F), cy + rh * (tick ? 0.4F : 0.2F), r * (tick ? 0.6F : 0.2F), rh * (tick ? 0.2F : 0.6F), cCard);
        }
        Box(g, x + w * 0.3F, y + h * 0.72F, w * 0.4F, h * 0.14F, cCard);
    }
    // LED-style volume dots
    void LedVolume(GTA.Graphics g, float x, float y, int vol)
    {
        int on = vol < 0 ? 0 : (int)Math.Round(vol / 10.0);
        for (int i = 0; i < 10; i++)
            Box(g, x + i * 0.0042F, y, 0.0028F, 0.010F, i < on ? (i >= 8 ? cAccent : cLed) : cTrack);
    }
    // bouncing equalizer bars
    void Bars(GTA.Graphics g, float x, float bottom, int n, bool paused)
    {
        double t = (DateTime.Now - DateTime.Today).TotalSeconds;
        for (int i = 0; i < n; i++)
        {
            float h = paused ? 0.003F : (float)(0.005 + 0.016 * Math.Abs(Math.Sin(t * (4.0 + i * 1.3) + i * 1.7)));
            Box(g, x + i * 0.0042F, bottom - h, 0.0028F, h, cAccent);
        }
    }

    double Elapsed(Song s)
    {
        double el; lock (sync) el = clockPaused ? clockBase : clockBase + (DateTime.Now - clockAt).TotalSeconds;
        if (el < 0) el = 0;
        if (s.Duration > 0 && el > s.Duration) el = s.Duration;
        return el;
    }
    static string Marquee(string t, int width)
    {
        if (t == null || t.Length <= width) return t ?? "";
        string loop = t + "     ";
        int off = (int)((DateTime.Now - DateTime.Today).TotalSeconds * 4) % loop.Length;
        return (loop + loop).Substring(off, width);
    }
    static string Time(double sec)
    {
        if (sec < 0 || double.IsNaN(sec)) sec = 0;
        int t = (int)sec; return (t / 60) + ":" + (t % 60).ToString("00");
    }
    static void Box(GTA.Graphics g, float x, float y, float w, float h, Color c) { g.DrawRectangle(new RectangleF(x, y, w, h), c); }
    static void Frame(GTA.Graphics g, float x, float y, float w, float h, Color c)
    {
        const float t = 0.001F; float tv = t * 1.7777F;
        Box(g, x, y, w, tv, c); Box(g, x, y + h - tv, w, tv, c); Box(g, x, y, t, h, c); Box(g, x + w - t, y, t, h, c);
    }
    static void Text(GTA.Graphics g, string t, float x, float y, float w, float h, GTA.Font f, TextAlignment a, Color c)
    {
        f.Color = c; g.DrawText(t ?? "", new RectangleF(x, y, w, h), a, f);
    }
    // screen shape, read on the game thread (game calls aren't allowed while drawing)
    static float screenFix;
    static float ScreenFix() { return screenFix > 0 ? screenFix : 1F; }
    void ReadScreen()
    {
        try
        {
            GTA.Native.Pointer pw = typeof(int), ph = typeof(int);
            GTA.Native.Function.Call("GET_SCREEN_RESOLUTION", pw, ph);
            int w = (int)pw, h = (int)ph;
            if (w > 0 && h > 0) screenFix = (w / (float)h) / 1.7777F;
        }
        catch { }
        if (screenFix <= 0) screenFix = 1F;
    }
    // a problem while drawing is written to scripts\NikoHeadphones.log (once per kind) instead of hiding the player
    string lastDrawError = "";
    void LogError(string where, Exception ex)
    {
        string msg = where + ": " + ex.GetType().Name + " - " + ex.Message;
        if (msg == lastDrawError) return;
        lastDrawError = msg;
        try { File.AppendAllText(Game.InstallFolder + "\\scripts\\NikoHeadphones.log", DateTime.Now.ToString("s") + "  " + msg + "\r\n" + ex.StackTrace + "\r\n"); } catch { }
    }
}

// small JSON reader (no extra files needed)
static class Json
{
    public static object Parse(string s)
    {
        if (String.IsNullOrEmpty(s)) return null;
        try { int i = 0; return Val(s, ref i); } catch { return null; }
    }
    static void Ws(string s, ref int i) { while (i < s.Length && Char.IsWhiteSpace(s[i])) i++; }
    static object Val(string s, ref int i)
    {
        Ws(s, ref i);
        char c = s[i];
        if (c == '{')
        {
            Dictionary<string, object> d = new Dictionary<string, object>(); i++;
            Ws(s, ref i); if (s[i] == '}') { i++; return d; }
            while (true)
            {
                Ws(s, ref i); string k = Str(s, ref i); Ws(s, ref i); i++; // :
                d[k] = Val(s, ref i); Ws(s, ref i);
                if (s[i] == ',') { i++; continue; }
                i++; return d;
            }
        }
        if (c == '[')
        {
            List<object> l = new List<object>(); i++;
            Ws(s, ref i); if (s[i] == ']') { i++; return l; }
            while (true)
            {
                l.Add(Val(s, ref i)); Ws(s, ref i);
                if (s[i] == ',') { i++; continue; }
                i++; return l;
            }
        }
        if (c == '"') return Str(s, ref i);
        if (s.Substring(i).StartsWith("true")) { i += 4; return true; }
        if (s.Substring(i, Math.Min(5, s.Length - i)) == "false") { i += 5; return false; }
        if (s.Substring(i, Math.Min(4, s.Length - i)) == "null") { i += 4; return null; }
        int st = i; while (i < s.Length && "+-0123456789.eE".IndexOf(s[i]) >= 0) i++;
        double v; double.TryParse(s.Substring(st, i - st), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v);
        return v;
    }
    static string Str(string s, ref int i)
    {
        StringBuilder sb = new StringBuilder(); i++;
        while (s[i] != '"')
        {
            char c = s[i++];
            if (c != '\\') { sb.Append(c); continue; }
            char e = s[i++];
            if (e == 'n') sb.Append('\n'); else if (e == 't') sb.Append('\t'); else if (e == 'r') { }
            else if (e == 'b' || e == 'f') { }
            else if (e == 'u') { sb.Append((char)Convert.ToInt32(s.Substring(i, 4), 16)); i += 4; }
            else sb.Append(e);
        }
        i++; return sb.ToString();
    }
    public static object Get(Dictionary<string, object> d, string k) { object v; return d != null && d.TryGetValue(k, out v) ? v : null; }
    public static object Path(object o, params string[] keys) { foreach (string k in keys) o = Get(o as Dictionary<string, object>, k); return o; }
    public static string Str(Dictionary<string, object> d, string k) { object v = Get(d, k); return v == null ? "" : (v is string ? (string)v : Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture)); }
    public static double Num(Dictionary<string, object> d, string k) { object v = Get(d, k); return v is double ? (double)v : 0; }
    public static bool Bool(Dictionary<string, object> d, string k) { object v = Get(d, k); return v is bool && (bool)v; }
}
