NIKO'S HEADPHONES - YouTube Music inside GTA IV
===============================================

A small modern music player for YouTube Music, with a little 90s touch.
It sits on the right side of the screen, under the wanted stars.

NEEDS
  - GTA IV: The Complete Edition with ScriptHookDotNet
  - The YouTube Music desktop app (th-ch / pear-desktop), open while you play
    In the app: Plugins > API Server > turn it on

INSTALL
  Drop this zip into Liberty City Mod Loader IV and press Install.
  Or copy the "scripts" folder into your GTA IV folder.

HOW TO USE
  F9      open or close the player (Niko stands still while it is open)
  Tab     next page: Play, Find, Lists, Queue

  Play    Enter play/pause   Left/Right skip   Up/Down volume
          L like   A add this song to your list

  Find    Type a song or artist, press Enter
          Down/Up choose   Enter play   A add to list   Q add to queue

  Lists   Your own playlists (saved on your PC)
          Enter play the list   Right open its songs
          T pick the list that A adds to   Delete (twice) removes a list
          [ New list ] makes a new one

  Queue   What plays next - Enter plays that song, A adds it to your list

FIRST TIME
  If it says "Waiting for YouTube Music", press Alt+Tab, click Allow
  in YouTube Music, and go back to the game. Only once.
  (If you already connected the Music button in Liberty City Mod Loader IV,
  it just works.)

SETTINGS
  scripts\NikoHeadphones.ini    key, port, song popup on/off
  scripts\NikoHeadphones.lists  your playlists

Made by AnnaEnxo - free and open source (GPL v3)
